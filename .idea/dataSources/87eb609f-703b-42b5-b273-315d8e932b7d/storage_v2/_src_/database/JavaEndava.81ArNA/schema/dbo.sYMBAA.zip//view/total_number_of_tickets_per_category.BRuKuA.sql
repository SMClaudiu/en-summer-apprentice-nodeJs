create   view total_number_of_tickets_per_category 
as select O.ticketCategoryId as CategorieTichet, SUM(numberOfTickets) as NumarTotalBilete, SUM(totalPrice) as CostTotalBilete
from Orders O
group by O.ticketCategoryId
go

